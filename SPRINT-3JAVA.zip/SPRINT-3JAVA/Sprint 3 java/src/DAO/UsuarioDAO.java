package DAO;

import beans.Usuario;
import conexoes.ConexaoFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UsuarioDAO {

    public Connection minhaConexao;

    public UsuarioDAO() throws SQLException, ClassNotFoundException {
        super();

        this.minhaConexao = new ConexaoFactory().conexao();
    }

    public String inserir(Usuario usuario) throws SQLException {
        PreparedStatement stmt = minhaConexao.prepareStatement
                ("INSERT INTO T_FIAP_USUARIO VALUES ( ?, ?, ?, ? )");

        stmt.setInt(1, usuario.getId());
        stmt.setString(2, usuario.getNome());
        stmt.setString(3, usuario.getSenha());
        stmt.setString(4, usuario.getDataCriacao());

        stmt.execute();
        stmt.close();

        return"Usuário Cadastrado com Sucesso!";
    }
}
